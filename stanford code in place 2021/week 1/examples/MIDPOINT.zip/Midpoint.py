from karel.stanfordkarel import *

"""
File: Midpoint.py
------------------------
Place a beeper in the middle of the first row.
"""

def main():
    """
    Your code here
    """
    put_beeper()
    while front_is_clear():
        move()
    put_beeper()
    

    
def turn_around():
    turn_left()
    turn_left()


if __name__ == '__main__':
    run_karel_program()
