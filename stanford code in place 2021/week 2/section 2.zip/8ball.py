"""
Simulates a magic eight ball.
Prompts the user to type a yes or no question and gives
a random answer from a set of prefabricated responses.
"""
import random
def main():
    # Printing instructions on how to ask questions and how to stop the program!
    print("You can ask any number of questions. If you want to quit, kindly, Enter quit!")
    eight_ball()

def eight_ball():
    #asking a question for name sake and generating a random number. Then displaying the 
    #output being already set for that particular number
    #assigning some garbage value to the variable 'question'
    question='This is Karel, the fortune teller!'
    while(question.upper()!='QUIT'):
        question=input("\nAsk a question:")
        guess=random.randint(1,20)
        if(guess==1):
            print("As I see it, yes.")
        if(guess==2):
            print("Ask again later.")
        if(guess==3):
            print("Better not to tell you now.")
        if(guess==4):
            print("Cannot predict now. ")
        if(guess==5):
            print("Concentrate and ask again.")
        if(guess==6):
            print("Don't count on it.")
        if(guess==7):
            print("It is certain.")
        if(guess==8):
            print("It is decidedly so.")
        if(guess==9):
            print("Most likely.")
        if(guess==10):
            print("My reply is no. ")
        if(guess==11):
            print("My sources say no.")
        if(guess==12):
            print("Outlook not so good.")
        if(guess==13):
            print("Outlook good. ")
        if(guess==14):
            print("Reply hazy, try again.")
        if(guess==15):
            print("Signs point to yes.")
        if(guess==16):
            print("Very doubtful.")
        if(guess==17):
            print("Without a doubt.")
        if(guess==18):
            print("Yes.")
        if(guess==19):
            print("Yes - definitely. ")
        if(guess==20):
            print("You may rely on it.")

if __name__ == "__main__":
    main()
