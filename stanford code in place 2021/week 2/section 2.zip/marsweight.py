"""
Prompts the user for a weight on Earth
and prints the equivalent weight on Mars.
"""
#Assigning a constant variable 'mars_constant' which denotes that the gravity of mars is 37.8 % of that of our Earth !
#mars_constant has global scope - can be used inside any functions, any number of times but the variable is updatable!
mars_constant=0.378
def main():
    # Fill this function out!
    #Getting the mass of a person in planet Earth
    earth_weight=int(input("Enter a weight on Earth:"))
    #displaying the mass of one on Mars by multiplying 0.378 to earth_weight
    print("The equivalent on Mars:",earth_weight*mars_constant)

if __name__ == "__main__":
    main()
